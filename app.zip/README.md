<video width="320" height="240" autoplay >
  <source src="movie.mp4" type="video/mp4">
  <source src="movie.ogg" type="video/ogg">
  Your browser does not support the video tag.
</video>



https://www.codeply.com/p/0CWffz76Q9
